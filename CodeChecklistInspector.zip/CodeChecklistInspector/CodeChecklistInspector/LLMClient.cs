﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CodeChecklistInspector
{
    public static class LLMClient
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private static readonly String apiKey = "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";

        public static async Task<string> SendPrompt(string prompt)
        {
            var requestBody = new
            {
                model = "gpt-4o-mini",
                messages = new[]
                {
                    new {role = "user", content = prompt}
                }
            };

            var requestContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");
            //requestContent.Headers.Add("Authorization", $"Bearer {apiKey}");
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", apiKey);

            var response = await httpClient.PostAsync("https://api.openai.com/v1/chat/completions", requestContent);
            response.EnsureSuccessStatusCode();
            var responseString = await response.Content.ReadAsStringAsync();

            var jsonDoc = JsonDocument.Parse(responseString);
            var message = jsonDoc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString();

            return message;
        }
    }
}
